function imDCT=q1_e(imqDCT,qm,c)
imDCT=imqDCT.*(c*qm);
end