function Y=q1_c(im,F)
Y=(F.')*im*F;
% imshow(uint8(Y));
end